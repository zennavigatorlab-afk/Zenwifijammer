# ZEN WIRELESS LAB
Dashboard for ESP32 firmware exposing GET /api/status, /api/wifi, /api/ble.
## Run
    npm install
    npm run dev      # then join Wi-Fi "ESP32-WIFI-SCANNER" and open Settings > Connect
    npm run build
## Deploy
Push to GitHub and import into Vercel (Vite preset). A deployed https site cannot call http://192.168.4.1 (mixed content) and cannot route to a private IP, so use `npm run dev` or `npm run preview` on a device connected to the ESP32.
## Firmware CORS
Add `Access-Control-Allow-Origin: *` to every ESP32 response (and handle OPTIONS if needed).
## Vercel steps
1. Push this folder to a GitHub repo.
2. vercel.com > Add New > Project > import the repo. Framework: Vite (auto-detected). Click Deploy.
3. Or use the CLI: `npm i -g vercel` then `vercel --prod`.
Note: the deployed https site can show the UI, but browsers block its calls to http://192.168.4.1 (mixed content). To read the ESP32, run the same code locally (`npm run dev` / `npm run preview`) while on the ESP32's Wi-Fi.
