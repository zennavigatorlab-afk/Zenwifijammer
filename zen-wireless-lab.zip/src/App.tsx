import { useCallback, useEffect, useState } from 'react'
import { Activity, Bluetooth, BookOpen, Clock, Cpu, LayoutDashboard, Moon, RefreshCw, Settings, Sun, Wifi, Unplug, Plug } from 'lucide-react'
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { BleDev, Status, WifiNet, asArray, fmtUptime, getJson, isStatus, quality, validateUrl } from './api'

type Tab = 'overview' | 'wifi' | 'ble' | 'system' | 'history' | 'learn' | 'settings'
type Snap<T> = { at: string; items: T[] }
const TABS: [Tab, string, typeof Wifi][] = [['overview', 'Overview', LayoutDashboard], ['wifi', 'Wi-Fi', Wifi], ['ble', 'BLE', Bluetooth], ['system', 'System', Cpu], ['history', 'History', Clock], ['learn', 'Learn', BookOpen], ['settings', 'Settings', Settings]]
const now = () => new Date().toLocaleTimeString()
const s = (v: unknown) => String(v ?? '')

function Err({ msg, retry }: { msg: string; retry: () => void }) {
  return <div className="err" role="alert">{msg} <button onClick={retry}>Retry</button></div>
}

export default function App() {
  const [tab, setTab] = useState<Tab>('overview')
  const [dark, setDark] = useState(true)
  const [url, setUrl] = useState(() => localStorage.getItem('esp32url') || 'http://192.168.4.1')
  const [base, setBase] = useState<string | null>(null)
  const [connErr, setConnErr] = useState('')
  const [ms, setMs] = useState<number | null>(null)
  const [lastOk, setLastOk] = useState('')
  const [busy, setBusy] = useState('')
  const [status, setStatus] = useState<Snap<Status> | null>(null)
  const [wifi, setWifi] = useState<Snap<WifiNet> | null>(null)
  const [ble, setBle] = useState<Snap<BleDev> | null>(null)
  const [err, setErr] = useState<Record<string, string>>({})
  const [wifiLog, setWifiLog] = useState<Snap<WifiNet>[]>([])
  const [q, setQ] = useState(''); const [ch, setCh] = useState('all'); const [sec, setSec] = useState('all'); const [sortDesc, setSortDesc] = useState(true)
  const [bq, setBq] = useState('')
  const [auto, setAuto] = useState(false)

  useEffect(() => { document.documentElement.dataset.theme = dark ? 'dark' : 'light' }, [dark])

  const loadStatus = useCallback(async (b: string) => {
    const r = await getJson<unknown>(b, '/api/status')
    if (!isStatus(r.data)) throw new Error('/api/status did not return the expected fields (ip, uptime, heap).')
    setStatus({ at: now(), items: [r.data] }); setMs(r.ms); setLastOk(now()); return r.data
  }, [])

  const connect = async () => {
    setConnErr(''); setBusy('connect')
    try { const b = validateUrl(url); await loadStatus(b); setBase(b); localStorage.setItem('esp32url', b); setUrl(b) }
    catch (e) { setBase(null); setConnErr((e as Error).message) }
    finally { setBusy('') }
  }
  const disconnect = () => { setBase(null); setAuto(false) }

  const scan = async (kind: 'wifi' | 'ble') => {
    if (!base || busy) return
    setBusy(kind); setErr(p => ({ ...p, [kind]: '' }))
    try {
      const path = kind === 'wifi' ? '/api/wifi' : '/api/ble'
      const r = await getJson<unknown>(base, path, 30000)
      setMs(r.ms); setLastOk(now())
      if (kind === 'wifi') { const snap = { at: now(), items: asArray<WifiNet>(r.data, path) }; setWifi(snap); setWifiLog(l => [snap, ...l].slice(0, 20)) }
      else setBle({ at: now(), items: asArray<BleDev>(r.data, path) })
    } catch (e) { setErr(p => ({ ...p, [kind]: (e as Error).message })) }
    finally { setBusy('') }
  }
  const refreshStatus = async () => { if (!base) return; try { await loadStatus(base); setErr(p => ({ ...p, system: '' })) } catch (e) { setErr(p => ({ ...p, system: (e as Error).message })) } }

  useEffect(() => { if (!base || !auto) return; const id = setInterval(refreshStatus, 10000); return () => clearInterval(id) }, [base, auto]) // eslint-disable-line

  const online = !!base
  const seenBefore = new Set(wifiLog.slice(1).flatMap(l => l.items.map(n => n.ssid)))
  const nets = (wifi?.items ?? []).filter(n => s(n.ssid).toLowerCase().includes(q.toLowerCase()) && (ch === 'all' || s(n.channel) === ch) && (sec === 'all' || s(n.security) === sec))
    .sort((a, b) => sortDesc ? b.rssi - a.rssi : a.rssi - b.rssi)
  const channels = [...new Set((wifi?.items ?? []).map(n => s(n.channel)))].sort((a, b) => +a - +b)
  const secs = [...new Set((wifi?.items ?? []).map(n => s(n.security)))]
  const devs = (ble?.items ?? []).filter(d => (s(d.name) + s(d.address)).toLowerCase().includes(bq.toLowerCase())).sort((a, b) => b.rssi - a.rssi)
  const stale = (t?: string) => t ? <span className="muted">Received {t}{online ? '' : ' (device disconnected, last known data)'}</span> : null
  const needConn = <p className="empty">Not connected. Open Settings and connect to your ESP32.</p>

  return (<div className="app">
    <nav aria-label="Main">
      <b className="brand"><Activity size={18} /> ZEN</b>
      {TABS.map(([id, label, Icon]) => <button key={id} className={tab === id ? 'on' : ''} onClick={() => setTab(id)} aria-current={tab === id}><Icon size={18} /><span>{label}</span></button>)}
    </nav>
    <main>
      <header>
        <h1>ZEN WIRELESS LAB</h1>
        <span className={'pill ' + (online ? 'ok' : 'bad')}>{online ? `Connected${ms !== null ? ` · ${ms} ms` : ''}` : 'Disconnected'}</span>
        <button className="icon" onClick={() => setDark(!dark)} aria-label="Toggle theme">{dark ? <Sun size={16} /> : <Moon size={16} />}</button>
      </header>

      {tab === 'overview' && <section>
        <div className="grid">
          <div className="card"><h3>Connection</h3><p>{online ? 'Connected' : 'Disconnected'}</p>{lastOk && <small>Last success {lastOk}</small>}</div>
          <div className="card"><h3>Wi-Fi networks</h3><p>{wifi ? wifi.items.length : 'No scan yet'}</p>{stale(wifi?.at)}</div>
          <div className="card"><h3>BLE advertisers</h3><p>{ble ? ble.items.length : 'No scan yet'}</p>{stale(ble?.at)}</div>
          <div className="card"><h3>Free heap</h3><p>{status ? `${status.items[0].heap} B` : 'No data'}</p>{stale(status?.at)}</div>
        </div>
        {!online && <p className="empty">Connect to your ESP32 in Settings to start. No data is shown until the device responds.</p>}
      </section>}

      {tab === 'wifi' && <section>
        <div className="bar"><button className="primary" disabled={!online || !!busy} onClick={() => scan('wifi')}><RefreshCw size={16} className={busy === 'wifi' ? 'spin' : ''} /> {busy === 'wifi' ? 'Scanning…' : 'Rescan'}</button>{stale(wifi?.at)}</div>
        {!online && !wifi && needConn}
        {err.wifi && <Err msg={err.wifi} retry={() => scan('wifi')} />}
        {wifi && <>
          <div className="bar">
            <input placeholder="Search SSID" value={q} onChange={e => setQ(e.target.value)} aria-label="Search SSID" />
            <select value={ch} onChange={e => setCh(e.target.value)} aria-label="Channel"><option value="all">All channels</option>{channels.map(c => <option key={c}>{c}</option>)}</select>
            <select value={sec} onChange={e => setSec(e.target.value)} aria-label="Security"><option value="all">All security</option>{secs.map(c => <option key={c}>{c}</option>)}</select>
            <button onClick={() => setSortDesc(!sortDesc)}>Signal {sortDesc ? '↓' : '↑'}</button>
          </div>
          <p className="muted">{wifi.items.length} networks returned by /api/wifi · showing {nets.length}. One scan is a snapshot; it cannot measure real channel congestion.</p>
          {wifi.items.length === 0 ? <p className="empty">The ESP32 returned no networks. Try rescanning.</p> : <>
            <div className="card chart"><ResponsiveContainer width="100%" height={Math.max(160, nets.length * 28)}>
              <BarChart data={nets.map(n => ({ name: s(n.ssid) || '(hidden)', rssi: n.rssi }))} layout="vertical" margin={{ left: 10 }}>
                <CartesianGrid strokeOpacity={0.2} /><XAxis type="number" domain={[-100, -30]} /><YAxis type="category" dataKey="name" width={90} /><Tooltip /><Bar dataKey="rssi" fill="var(--accent)" name="RSSI (dBm)" /></BarChart></ResponsiveContainer></div>
            <div className="scroll"><table><thead><tr><th>SSID</th><th>dBm</th><th>Quality</th><th>Ch</th><th>Security</th></tr></thead>
              <tbody>{nets.map((n, i) => <tr key={i}><td>{s(n.ssid) || '(hidden)'}</td><td>{n.rssi}</td><td>{quality(n.rssi)}</td><td>{s(n.channel)}</td><td>{s(n.security)}</td></tr>)}</tbody></table></div>
          </>}
        </>}
      </section>}

      {tab === 'ble' && <section>
        <div className="bar"><button className="primary" disabled={!online || !!busy} onClick={() => scan('ble')}><RefreshCw size={16} className={busy === 'ble' ? 'spin' : ''} /> {busy === 'ble' ? 'Scanning…' : 'Scan BLE'}</button><input placeholder="Search name or address" value={bq} onChange={e => setBq(e.target.value)} aria-label="Search BLE" />{stale(ble?.at)}</div>
        <p className="muted">The firmware lists BLE advertisements it hears, not every Bluetooth device nearby. Many devices advertise no name.</p>
        {!online && !ble && needConn}
        {err.ble && <Err msg={err.ble} retry={() => scan('ble')} />}
        {ble && (devs.length === 0 ? <p className="empty">No advertisements to show.</p> :
          <div className="scroll"><table><thead><tr><th>Name</th><th>Address</th><th>dBm</th></tr></thead><tbody>{devs.map((d, i) => <tr key={i}><td>{s(d.name) || '(no name advertised)'}</td><td>{s(d.address)}</td><td>{d.rssi}</td></tr>)}</tbody></table></div>)}
      </section>}

      {tab === 'system' && <section>
        <div className="bar"><button className="primary" disabled={!online} onClick={refreshStatus}><RefreshCw size={16} /> Refresh</button>
          <label><input type="checkbox" checked={auto} disabled={!online} onChange={e => setAuto(e.target.checked)} /> Auto-refresh every 10 s</label>{stale(status?.at)}</div>
        {err.system && <Err msg={err.system} retry={refreshStatus} />}
        {!status ? needConn : <div className="grid">
          <div className="card"><h3>Access point</h3><p>{s(status.items[0].ap)}</p></div>
          <div className="card"><h3>IP address</h3><p>{s(status.items[0].ip)}</p></div>
          <div className="card"><h3>Clients</h3><p>{s(status.items[0].clients)}</p></div>
          <div className="card"><h3>Uptime</h3><p>{fmtUptime(Number(status.items[0].uptime))}</p></div>
          <div className="card"><h3>Free heap</h3><p>{s(status.items[0].heap)} B</p></div></div>}
      </section>}

      {tab === 'history' && <section>
        <p className="muted">History comes from the firmware's in-memory "history" field and resets when the ESP32 restarts. A network marked new is only unfamiliar to this session, not suspicious. Below, scans from this browser session are listed with timestamps.</p>
        {wifiLog.length === 0 ? <p className="empty">No Wi-Fi scans received yet.</p> : wifiLog.map((l, i) => <details key={i} className="card" open={i === 0}><summary>{l.at} · {l.items.length} networks</summary>
          <div className="scroll"><table><thead><tr><th>SSID</th><th>Firmware history</th><th>Session</th></tr></thead><tbody>{l.items.map((n, j) => <tr key={j}><td>{s(n.ssid) || '(hidden)'}</td><td>{s(n.history)}</td><td>{i === wifiLog.length - 1 ? 'First scan' : seenBefore.has(n.ssid) ? 'Seen earlier' : 'New this session'}</td></tr>)}</tbody></table></div></details>)}
      </section>}

      {tab === 'learn' && <section className="learn">
        {[['RSSI', 'Received signal strength in dBm. Closer to 0 is stronger: -50 is excellent, -70 is fair, below -80 is unreliable. It fluctuates with walls, movement and antenna orientation.'],
          ['Channels', 'On 2.4 GHz, channels 1, 6 and 11 do not overlap. Networks on the same or neighbouring channels share airtime.'],
          ['Open vs protected', 'Open networks send traffic unencrypted. WPA2/WPA3 encrypt it. Security type alone says nothing about whether a network is trustworthy.'],
          ['BLE advertisements', 'BLE devices broadcast short packets so others can find them. A scanner only sees devices that advertise while it listens.'],
          ['Interference', 'Microwaves, other radios and crowded channels add noise, so RSSI and throughput vary between scans.'],
          ['Monitoring vs transmitting', 'This app only listens through your own ESP32. Transmitting to disrupt others\' signals (jamming, deauthentication) is illegal in most places and is not part of this project.']]
          .map(([t, d]) => <div className="card" key={t}><h3>{t}</h3><p>{d}</p></div>)}
      </section>}

      {tab === 'settings' && <section>
        <div className="card"><h3>ESP32 connection</h3>
          <input value={url} onChange={e => setUrl(e.target.value)} aria-label="ESP32 base URL" />
          <div className="bar"><button className="primary" disabled={busy === 'connect'} onClick={connect}><Plug size={16} /> {busy === 'connect' ? 'Connecting…' : 'Connect'}</button>
            <button onClick={connect} disabled={busy === 'connect'}>Test connection</button>
            <button onClick={disconnect} disabled={!online}><Unplug size={16} /> Disconnect</button></div>
          {connErr && <Err msg={connErr} retry={connect} />}
          {online && <p className="muted">Connected · {ms} ms · last success {lastOk}</p>}
          {location.protocol === 'https:' && url.startsWith('http:') && <p className="err">This page is on https, so browsers block requests to http addresses (mixed content). Run the app locally with npm run dev, or serve the ESP32 over https.</p>}
        </div>
        <div className="card"><h3>Before you connect</h3>
          <p>Your phone or computer must join the Wi-Fi network ESP32-WIFI-SCANNER (default http://192.168.4.1). A site hosted on Vercel cannot reach a private ESP32 address over the internet; only your own device's browser can.</p>
          <p>The browser also needs permission to read the ESP32's responses. Add CORS headers in the firmware, for example with ESPAsyncWebServer: <code>DefaultHeaders::Instance().addHeader("Access-Control-Allow-Origin", "*");</code> or with WebServer: <code>server.sendHeader("Access-Control-Allow-Origin", "*");</code> before each send. Wi-Fi and BLE scans run one at a time here.</p></div>
      </section>}
    </main></div>)
}
