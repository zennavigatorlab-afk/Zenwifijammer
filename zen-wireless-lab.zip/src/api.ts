export interface Status { ap: unknown; ip: string; clients: number; uptime: number; heap: number }
export interface WifiNet { ssid: string; rssi: number; signal: unknown; channel: number; security: string; history: unknown }
export interface BleDev { name: string; address: string; rssi: number }

export function validateUrl(raw: string): string {
  let u: URL
  try { u = new URL(raw.trim()) } catch { throw new Error('Enter a full address such as http://192.168.4.1') }
  if (u.protocol !== 'http:' && u.protocol !== 'https:') throw new Error('Only http:// or https:// addresses are accepted.')
  return u.origin
}

export async function getJson<T>(base: string, path: string, timeoutMs = 10000): Promise<{ data: T; ms: number }> {
  const ctrl = new AbortController()
  const t = setTimeout(() => ctrl.abort(), timeoutMs)
  const start = performance.now()
  try {
    const res = await fetch(base + path, { signal: ctrl.signal, cache: 'no-store' })
    if (!res.ok) throw new Error(`ESP32 returned HTTP ${res.status} for ${path}.`)
    let data: unknown
    try { data = await res.json() } catch { throw new Error(`${path} did not return valid JSON.`) }
    return { data: data as T, ms: Math.round(performance.now() - start) }
  } catch (e) {
    if (e instanceof DOMException && e.name === 'AbortError') throw new Error(`No response from ${path} within ${timeoutMs / 1000}s. Check that your device can reach the ESP32.`)
    if (e instanceof TypeError) throw new Error('Request blocked or unreachable. Causes: not on the ESP32 network, missing CORS headers in firmware, or an https page calling an http address (mixed content).')
    throw e
  } finally { clearTimeout(t) }
}

export const isStatus = (d: unknown): d is Status => !!d && typeof d === 'object' && 'ip' in d && 'uptime' in d && 'heap' in d
export const asArray = <T,>(d: unknown, path: string): T[] => { if (!Array.isArray(d)) throw new Error(`${path} returned an unexpected shape (expected a JSON array).`); return d as T[] }
export const quality = (r: number) => r >= -50 ? 'Excellent' : r >= -60 ? 'Good' : r >= -70 ? 'Fair' : 'Weak'
export const fmtUptime = (s: number) => `${Math.floor(s / 3600)}h ${Math.floor((s % 3600) / 60)}m ${Math.floor(s % 60)}s`
